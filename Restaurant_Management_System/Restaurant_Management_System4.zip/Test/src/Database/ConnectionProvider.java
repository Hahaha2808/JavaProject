/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;
import java.sql.*; 

public class ConnectionProvider {
    public static Connection getCon() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/javaprojectdb?useSSL=false", 
                "root", 
                "Mysql2024"
            );
            return con;
        }
        catch(Exception e) {
            e.printStackTrace();  // This will print the actual error
            return null;
        }
    }
    
    public static void main(String[] args) {
        Connection c = getCon();
        if (c == null) {
            System.out.println("something wrong");
        } else {
            System.out.println("ok");
        }
    }
      public static void checkUserTable(Connection con) {
        String query = "SELECT * FROM User";
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                System.out.println("Staff_id: " + rs.getInt("Staff_id"));
                System.out.println("Username: " + rs.getString("Username"));
                System.out.println("Password: " + rs.getString("Password"));
                System.out.println("Name: " + rs.getString("Name"));
                System.out.println("DoB: " + rs.getDate("DoB"));
                System.out.println("Phone: " + rs.getString("Phone"));
                System.out.println("Email: " + rs.getString("Email"));
                System.out.println("Role: " + rs.getString("Role"));
                System.out.println("Manager_id: " + rs.getInt("Manager_id"));
                System.out.println();
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

