package Controller;

import javax.swing.JOptionPane;
import model.User;
import java.sql.*;
import Database.DbOperations;

public class Userdao {
    public static User login(String username, String password) {  // Changed return type from void to User
        User user = null;
        try {
            ResultSet rs = DbOperations.getData("select * from User where username = '" 
                    + username + "' and password = '" + password + "'");
            while(rs.next()) {
                user = new User();
                user.setStatus(rs.getString("status"));
                user.setRole(rs.getString("role"));      // Add this to get role
                user.setUsername(rs.getString("username")); // Add this
                user.setPassword(rs.getString("password")); // Add this
            }
        }
        catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return user;  // Add return statement
    }
}