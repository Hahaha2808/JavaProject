package model;

public class Item {
    // Attributes
    private int itemID;
    private String name;
    private String description;
    private String price;
    private boolean availability;
    private String size; // Assuming size is a single character
    private String itemType;

    // Constructor
    public Item(int itemID, String name, String description, String price, boolean availability, String size, String itemType) {
        this.itemID = itemID;
        this.name = name;
        this.description = description;
        this.price = price;
        this.availability = availability;
        this.size = size;
        this.itemType = itemType;
    }

    // Getter and Setter methods
    public int getItemID() {
        return itemID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public boolean isAvailable() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    // Method to get item info
    public String getItemInfo() {
        return "Item ID: " + itemID + "\n" +
               "Name: " + name + "\n" +
               "Description: " + description + "\n" +
               "Price: $" + price + "\n" +
               "Availability: " + (availability ? "Yes" : "No") + "\n" +
               "Size: " + size + "\n" +
               "Item Type: " + itemType;
    }
}

// Drink class extending Item
class Drink extends Item {
    // Attribute specific to Drink
    private boolean isAlcoholic;

    // Constructor
    public Drink(int itemID, String name, String description, String price, boolean availability, String size, boolean isAlcoholic) {
        super(itemID, name, description, price, availability, size, "Drink");
        this.isAlcoholic = isAlcoholic;
    }

    // Setter for alcoholic status
    public void setAlcoholic(boolean isAlcoholic) {
        this.isAlcoholic = isAlcoholic;
    }

    // Getter for alcoholic status
    public boolean isAlcoholic() {
        return isAlcoholic;
    }

    // Override getItemInfo to include alcoholic info
    @Override 
    public String getItemInfo() {
        return super.getItemInfo() + "\nAlcoholic: " + (isAlcoholic ? "Yes" : "No");
    }
}

// Food class extending Item
class Food extends Item {
    // Attribute specific to Food
    private boolean isSpicy;

    // Constructor 
    public Food(int itemID, String name, String description, String price, boolean availability, String size, boolean isSpicy) {
        super(itemID, name, description, price, availability, size, "Food");
        this.isSpicy = isSpicy;
    }

    // Setter for spicy status
    public void setSpicy(boolean isSpicy) {
        this.isSpicy = isSpicy;
    }

    // Getter for spicy status
    public boolean isSpicy() {
        return isSpicy;
    }

    // Override getItemInfo to include spice level
    @Override
    public String getItemInfo() {
        return super.getItemInfo() + "\nSpicy: " + (isSpicy ? "Yes" : "No");
    }
}
