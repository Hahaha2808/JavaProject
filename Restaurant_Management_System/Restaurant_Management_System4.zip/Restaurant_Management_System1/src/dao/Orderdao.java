/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Item;
import model.Order;

/**
 *
 * @author DELL
 */
public class Orderdao {
    
    private Connection connection;

    public Orderdao(Connection connection) {
        this.connection = connection;
    }

    // Method to fetch all items for the menu
    public List<Item> fetchAllItems() throws SQLException {
        String query = "SELECT * FROM item";
        List<Item> items = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                items.add(new Item(
                    rs.getInt("ItemID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getFloat("Price"),
                    rs.getBoolean("Availability")
                ));
            }
        }
        return items;
    }

    // Method to search for an item by name
    public Item searchItemByName(String itemName) throws SQLException {
        String query = "SELECT * FROM item WHERE Name LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + itemName + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Item(
                        rs.getInt("ItemID"),
                        rs.getString("Name"),
                        rs.getString("Description"),
                        rs.getFloat("Price"),
                        rs.getBoolean("Availability")
                    );
                }
            }
        }
        return null;  // Return null if item not found
    }

    // Method to save an order and its associated items
    public int saveOrderWithItems(Order order, List<OrderItem> orderItems) throws SQLException {
        String orderQuery = "INSERT INTO `order` (CustomerName, PhoneNumber, OrderDate, TotalPrice, OrderStatus) " +
                            "VALUES (?, ?, ?, ?, 'Pending')";
        String orderItemQuery = "INSERT INTO orderitems (OrderID, ItemID, Quantity, Price) VALUES (?, ?, ?, ?)";

        try (PreparedStatement orderStmt = connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement orderItemStmt = connection.prepareStatement(orderItemQuery)) {

            // Insert the order
            orderStmt.setString(1, order.getCustomerName());
            orderStmt.setString(2, order.getPhoneNumber());
            orderStmt.setDate(3, new java.sql.Date(order.getOrderDate().getTime()));
            orderStmt.setDouble(4, order.getTotalPrice());
            int affectedRows = orderStmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating order failed, no rows affected.");
            }

            // Retrieve generated order ID
            int orderID;
            try (ResultSet generatedKeys = orderStmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    orderID = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating order failed, no ID obtained.");
                }
            }

            // Insert associated order items
            for (OrderItem item : orderItems) {
                orderItemStmt.setInt(1, orderID);
                orderItemStmt.setInt(2, item.getItemID());
                orderItemStmt.setInt(3, item.getQuantity());
                orderItemStmt.setDouble(4, item.getPrice());
                orderItemStmt.addBatch();
            }
            orderItemStmt.executeBatch();

            return orderID;  // Return the generated order ID
        }
    }

    // Method to update order status
    public boolean updateOrderStatus(int orderID, String status) throws SQLException {
        String query = "UPDATE `order` SET OrderStatus = ? WHERE OrderID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, status);
            stmt.setInt(2, orderID);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;  // Return true if update is successful
        }
    }

    // Existing methods for getting items for an order and deleting an order remain unchanged
    public List<OrderItem> getItemsForOrder(int orderID) throws SQLException {
        String query = "SELECT oi.ItemID, i.Name, oi.Quantity, oi.Price FROM orderitems oi " +
                       "JOIN item i ON oi.ItemID = i.ItemID WHERE oi.OrderID = ?";
        List<OrderItem> items = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderID);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    items.add(new OrderItem(
                        rs.getInt("ItemID"),
                        rs.getString("Name"),
                        rs.getInt("Quantity"),
                        rs.getDouble("Price")
                    ));
                }
            }
        }
        return items;
    }

    // Method to delete an order and its associated items
    public boolean deleteOrder(int orderID) throws SQLException {
        String deleteItemsQuery = "DELETE FROM orderitems WHERE OrderID = ?";
        String deleteOrderQuery = "DELETE FROM `order` WHERE OrderID = ?";

        try (PreparedStatement deleteItemsStmt = connection.prepareStatement(deleteItemsQuery);
             PreparedStatement deleteOrderStmt = connection.prepareStatement(deleteOrderQuery)) {

            // Delete associated items first
            deleteItemsStmt.setInt(1, orderID);
            deleteItemsStmt.executeUpdate();

            // Then delete the order itself
            deleteOrderStmt.setInt(1, orderID);
            int affectedRows = deleteOrderStmt.executeUpdate();
            return affectedRows > 0;  // Return true if the order was deleted
        }
    }
}

