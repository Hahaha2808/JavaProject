/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author DELL
 */
import model.Item;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Itemdao {
    public static void save(Item item){
        String query = "INSERT INTO item (name, description, price, availability) VALUES ('"+item.getName()+"',"+item.getDescription()+"',"+item.getPrice()+"',"+item.isAvailable()+"',"+item.getItemType()+"')";
        DbOperations.setDataOrDelete(query,"Item Added Successfully");
    }
    //private Connection connection;

    // Constructor
    //public Itemdao(Connection connection) {
        //this.connection = connection;
    //}

    // Method to add an item to the database
    /*public boolean addItem(Item item) {
        String query = "INSERT INTO item (name, description, price, availability) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, item.getName());
            stmt.setString(2, item.getDescription());
            stmt.setFloat(3, item.getPrice());
            stmt.setBoolean(4, item.isAvailable());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }*/
    
    // Method to update an item in the database
    /*public boolean updateItem(Item item) {
        String query = "UPDATE item SET name = ?, description = ?, price = ?, availability = ? WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, item.getName 
            stmt.setString(2, item.getDescription());
            stmt.setFloat(3, item.getPrice());
            stmt.setBoolean(4, item.isAvailable());
            stmt.setInt(5, item.getItemID());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete an item from the database
    public boolean deleteItem(int itemID) {
        String query = "DELETE FROM item WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to get an item by ID
    public Item getItemById(int itemID) {
        String query = "SELECT * FROM item WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Item(
                        rs.getInt("itemID"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getFloat("price"),
                        rs.getBoolean("availability")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to get all items in the database
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        String query = "SELECT * FROM item";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                items.add(new Item(
                        rs.getInt("itemID"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getFloat("price"),
                        rs.getBoolean("availability")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }*/
}

