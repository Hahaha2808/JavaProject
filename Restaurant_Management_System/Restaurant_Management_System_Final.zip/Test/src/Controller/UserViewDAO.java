package Controller;

import model.User;
import java.sql.*;
import java.util.ArrayList;

public class UserViewDAO {
    private Connection connection;

    // Constructor to initialize with a provided connection
    public UserViewDAO(Connection connection) {
        this.connection = connection;
    }

    // Method to fetch all active users
    public ArrayList<User> getAllUsers() {
        ArrayList<User> userList = new ArrayList<>();
        String query = "SELECT Staff_id, Username, DoB, Phone, Email, Role FROM user";

        try (PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                User user = new User();
                user.setStaffId(rs.getInt("Staff_id"));
                user.setUsername(rs.getString("Username"));
                user.setDob(rs.getDate("DoB"));
                user.setPhone(rs.getString("Phone"));
                user.setEmail(rs.getString("Email"));
                user.setRole(rs.getString("Role"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return userList;
    }
}
