package Controller;

import java.sql.*;
import java.util.List;
import model.Order;
import model.OrderItem;
import model.Item;
import Controller.ItemDAO;
import java.util.ArrayList;

public class OrderController {
    private OrderDAO orderDAO;
    private ItemController itemController;

    public OrderController(Connection connection) {
        this.orderDAO = new OrderDAO(connection);
    }

    // Method to create a new order with associated items
    public int createNewOrder(Order order, List<OrderItem> orderItems) {
        try {
            return orderDAO.saveOrderWithItems(order,orderItems);
        } catch (SQLException e) {
            System.out.println("Error creating new order: " + e.getMessage());
            return -1;  // Indicate failure
        }
    }

    // Method to finalize the order (mark it as complete)
    public boolean finalizeOrder(Order order) {
        order.closeOrder();
        return orderDAO.updateOrderStatus(order.getOrderID(), "Completed");
    }

    // Method to view items in the order
    public List<OrderItem> viewItemsInOrder(int orderID) {
        try {
            return orderDAO.getItemsForOrder(orderID);
        } catch (SQLException e) {
            System.out.println("Error fetching items for order: " + e.getMessage());
            return null;  // Indicate failure
        }
    }

    // Method to delete an order
    public boolean deleteOrder(int orderID) {
        try {
            return orderDAO.deleteOrder(orderID);
        } catch (SQLException e) {
            System.out.println("Error deleting order: " + e.getMessage());
            return false;  // Indicate failure
        }
    }

    // Method to calculate the total of the items in the order
    public float calculateOrderTotal(List<OrderItem> orderItems) {
        float total = 0;
        for (OrderItem item : orderItems) {
            total += item.getQuantity() * item.getPrice();
        }
        return total;
    }
    
    // Get next order ID
    public int getNextOrderID() {
        try {
            return orderDAO.getNextOrderID();  // Call the DAO method to get the next OrderID
        } catch (SQLException e) {
            System.out.println("Error fetching next order ID: " + e.getMessage());
            return -1;  // Return a default value in case of an error
        }
    }
        // Get all orders from the database (with the status mapped to a String)
    public List<Order> getAllOrders() {
        try {
            return orderDAO.fetchAllOrders();  // Fetch orders from DAO
        } catch (SQLException e) {
            System.out.println("Error fetching orders: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    // Calculate the total price for the given order ID (unchanged)
    public float getOrderTotal(int orderID) {
        try {
            return orderDAO.calculateOrderTotal(orderID);  // Call Model to get the total
        } catch (SQLException e) {
            System.out.println("Error fetching order total: " + e.getMessage());
            return 0;
        }
    }
    
    // Method to update order status
    public boolean updateOrderStatus(int orderID, boolean status) {
        // Convert the boolean status to a string
        String statusString = status ? "Completed" : "In Progress";

        // Pass the statusString to the DAO method
        return orderDAO.updateOrderStatus(orderID, statusString);
}
}

