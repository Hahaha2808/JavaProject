package Controller;

import model.User;
import java.util.List;


public class UserViewController {
    private UserViewDAO userViewDAO;

    // Constructor to initialize UserViewDAO
    public UserViewController(UserViewDAO userViewDAO) {
        if (userViewDAO == null) {
            throw new IllegalArgumentException("UserViewDAO cannot be null");
        }
        this.userViewDAO = userViewDAO;
    }

    public List<User> getAllUsers() {
        return userViewDAO.getAllUsers();
    }
}

