package model;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Waiter extends User {
    private List<Order> orders;

    // Constructor matching User's full constructor
    public Waiter(int staffID, String username, String password, String name, Date dob, 
                  String phone, String email, int managerId, String status) {
        super();
        this.orders = new ArrayList<>();
    }

    // Existing methods remain the same
    public void newOrder(Order order) {
        orders.add(order);
        System.out.println("New order created: " + order.getOrderID());
    }

    
    public void SubmitOrder(Order order) {
        System.out.println("Submit order: " + order.getOrderID());
        // Implementation for generating invoice
    }
}
