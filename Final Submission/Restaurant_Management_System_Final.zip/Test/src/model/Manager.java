package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Manager extends User {
    private List<User> subordinates;
    private List<Item> menu;

    // Constructor with full User parameters
    public Manager(int staffID, String username, String password, String name, Date dob, 
                   String phone, String email, int managerId, String status) {
        super();
        this.subordinates = new ArrayList<>();
        this.menu = new ArrayList<>();
    }

    // Methods remain the same as in the original implementation
    public void addMenuItem(Item item) {
        menu.add(item);
        System.out.println("Added item to menu: " + item.getName());
    }

    public void deleteItem(Item item) {
        menu.remove(item);
        System.out.println("Removed item from menu: " + item.getName());
    }
    public void updateItem(Item oldItem, Item newItem) {
    int index = menu.indexOf(oldItem);
    if (index != -1) {
        menu.set(index, newItem);
        System.out.println("Updated item: " + oldItem.getName() + " to " + newItem.getName());
    } else {
        System.out.println("Item not found in menu.");
    }
}

    public void viewStaff() {
        System.out.println("Viewing all subordinates:");
        for (User staff : subordinates) {
            System.out.println("- " + staff.getName());
        }
    }
}