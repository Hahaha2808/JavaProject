/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;


import java.util.Date;

public class User {
    private int staffId;
    private String username;
    private String password;
    private String name;
    private Date dob;
    private String phone;
    private String email;
    private String role;
    private int managerId;
    private String status;
    
    // Full constructor
    public User(int staffId, String username, String password, String name, Date dob, 
                String phone, String email, String role, int managerId, String status) {
        this.staffId = staffId;
        this.username = username;
        this.password = password;
        this.name = name;
        this.dob = dob;
        this.phone = phone;
        this.email = email;
        this.role = role;
        this.managerId = managerId;
        this.status = status;
    }

    public User() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    // Getters
    public int getStaffId() { return staffId; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getName() { return name; }
    public Date getDob() { return dob; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getRole() { return role; }
    public int getManagerId() { return managerId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Setters
    public void setStaffId(int staffId) { this.staffId = staffId; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setName(String name) { this.name = name; }
    public void setDob(Date dob) { this.dob = dob; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setEmail(String email) { this.email = email; }
    public void setRole(String role) { this.role = role; }
    public void setManagerId(int managerId) { this.managerId = managerId; }
}
