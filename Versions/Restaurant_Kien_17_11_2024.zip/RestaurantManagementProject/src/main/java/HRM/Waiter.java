package HRM;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Waiter extends Staff {
    private List<Order> orders;
    private Manager manager; // Reference to Manager

    public Waiter(Account account, int staffID, String name, Date dob, String phone, String email, Manager manager) {
        super(account, staffID, name, dob, phone, email, "Waiter");
        this.orders = new ArrayList<>();
        this.manager = manager; // Set the manager when creating the waiter
    }

    public void newOrder(Order order) {
        orders.add(order);
        System.out.println("New order created: " + order.getOrderID());
    }

    public void deleteOrder(Order order) {
        orders.remove(order);
        System.out.println("Order deleted: " + order.getOrderID());
    }

    public void generateInvoice(Order order) {
        System.out.println("Invoice for Order ID: " + order.getOrderID());
        float total = order.getTotalPrice(); // Using calculateTotal() from Order.java
        System.out.println("Total: " + total);
    }

    public void viewOrders() {
        System.out.println("Orders handled by this waiter:");
        for (Order order : orders) {
            System.out.println("- Order ID: " + order.getOrderID());
        }
    }

    // New Methods
    public List<Item> getMenu() {
        if (manager != null) {
            return manager.getMenu(); // Get menu from the manager
        } else {
            System.out.println("Manager not assigned.");
            return new ArrayList<>(); // Return an empty menu if manager is not set
        }
    }

    public List<Order> getOrders() {
        return orders;
    }
}
