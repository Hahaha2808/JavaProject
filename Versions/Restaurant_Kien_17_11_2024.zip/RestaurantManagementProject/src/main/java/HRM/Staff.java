package HRM;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Staff {
    Account account;
    private int staffID;
    String name;
    private Date dob;
    String phone;
    String email;
    private String role;
    private List<Item> menu;
    private List<Order> orders;

    // Constructor
    public Staff(Account account, int staffID, String name, Date dob, String phone, String email, String role) {
        this.account = account;
        this.staffID = staffID;
        this.name = name;
        this.dob = dob;
        this.phone = phone;
        this.email = email;
        this.role = role;
        this.menu = new ArrayList<>();
        this.orders = new ArrayList<>();
    }

    // Getters and Setters
    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public int getStaffID() {
        return staffID;
    }

    public void setStaffID(int staffID) {
        this.staffID = staffID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Methods - Staff actions common to all roles
    public void getOrderInfo() {
        if (role.equals("Manager")) {
            // Manager sees all orders (or specific order details can be added)
            System.out.println("Manager is viewing all orders (details to be implemented).");
            for (Order order : orders) {
                System.out.println(order.viewOrder());
            }
        } else if (role.equals("Waiter")) {
            // Waiter sees their own orders
            System.out.println("Waiter is viewing their orders:");
            for (Order order : orders) {
                System.out.println(order.viewOrder());
            }
        }
    }

    public void viewMenu() {
        if (role.equals("Manager")) {
            // Manager sees the full menu
            System.out.println("Manager is viewing the full menu:");
            for (Item item : menu) {
                System.out.println("- " + item.getName() + ": " + item.getPrice());
            }
        } else if (role.equals("Waiter")) {
            // Waiter sees the items of orders they are handling
            System.out.println("Waiter is viewing the menu:");
            for (Order order : orders) {
                for (Item item : order.orderItems) {  // Access orderItems directly
                    System.out.println("- " + item.getName() + ": " + item.getPrice());
                }
            }
        }
    }

    // Helper Methods to add and manage orders and menu items (common functionality)
    public void addMenuItem(Item item) {
        menu.add(item);
        System.out.println("Added item to menu: " + item.getName());
    }

    public void addOrder(Order order) {
        orders.add(order);
        System.out.println("Added order for " + order.getCustomerName() + ": " + order.getOrderID());
    }

    public void deleteOrder(Order order) {
        orders.remove(order);
        System.out.println("Deleted order: " + order.getOrderID());
    }
}
