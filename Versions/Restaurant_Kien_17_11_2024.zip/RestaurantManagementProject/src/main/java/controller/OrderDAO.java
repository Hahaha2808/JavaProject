package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import HRM.Item;
import HRM.Order;

public class OrderDAO {
    private Connection connection;

    public OrderDAO(Connection connection) {
        this.connection = connection;
    }

    // Method to fetch all items for the menu
    public List<Item> fetchAllItems() throws SQLException {
        String query = "SELECT * FROM item";
        List<Item> items = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                items.add(new Item(
                    rs.getInt("ItemID"),
                    rs.getString("Name"),
                    rs.getString("Description"),
                    rs.getFloat("Price"),
                    rs.getBoolean("Availability")
                ));
            }
        }
        return items;
    }

    // Method to search for an item by name
    public Item searchItemByName(String itemName) throws SQLException {
        String query = "SELECT * FROM item WHERE Name LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + itemName + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Item(
                        rs.getInt("ItemID"),
                        rs.getString("Name"),
                        rs.getString("Description"),
                        rs.getFloat("Price"),
                        rs.getBoolean("Availability")
                    );
                }
            }
        }
        return null;  // Return null if item not found
    }

    // Method to save an order and its associated items
    public int saveOrderWithItems(Order order, List<OrderItem> orderItems) throws SQLException {
        String orderQuery = "INSERT INTO `order` (CustomerName, PhoneNumber, OrderDate, OrderStatus) VALUES (?, ?, ?, ?)";
        String orderItemQuery = "INSERT INTO orderitems (OrderID, ItemID, Quantity) VALUES (?, ?, ?)";

        try (PreparedStatement orderStmt = connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement orderItemStmt = connection.prepareStatement(orderItemQuery)) {

            // Insert the order
            orderStmt.setString(1, order.getCustomerName());
            orderStmt.setString(2, order.getPhoneNumber());
            orderStmt.setDate(3, new java.sql.Date(order.getOrderDate().getTime()));
            orderStmt.setInt(4, 0);
            int affectedRows = orderStmt.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating order failed, no rows affected.");
            }

            // Retrieve generated order ID
            int orderID;
            try (ResultSet generatedKeys = orderStmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    orderID = generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Creating order failed, no ID obtained.");
                }
            }

            // Insert associated order items
            for (OrderItem item : orderItems) {
                orderItemStmt.setInt(1, orderID);
                orderItemStmt.setInt(2, item.getItemID());
                orderItemStmt.setInt(3, item.getQuantity());
                orderItemStmt.addBatch();
            }
            orderItemStmt.executeBatch();

            return orderID;  // Return the generated order ID
        }
    }


    // Method to update order status
    public boolean updateOrderStatus(int orderID, String status) {
        // Map the string status to an integer value
        int statusCode = 0;  // Default to "Open"
        if ("Completed".equalsIgnoreCase(status)) {
            statusCode = 1;  // "Completed" corresponds to 1
        }

        // Your existing code to update the status in the database
        String query = "UPDATE `order` SET OrderStatus = ? WHERE orderID = ?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, statusCode);  // Use the integer status code
            pst.setInt(2, orderID);
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;  // Return true if the update was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }



    // Existing methods for getting items for an order and deleting an order remain unchanged
    public List<OrderItem> getItemsForOrder(int orderID) throws SQLException {
        String query = "SELECT oi.ItemID, i.Name, oi.Quantity, oi.Price FROM orderitems oi " +
                       "JOIN item i ON oi.ItemID = i.ItemID WHERE oi.OrderID = ?";
        List<OrderItem> items = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderID);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    items.add(new OrderItem(
                        rs.getInt("ItemID"),
                        rs.getInt("Quantity")
                    ));
                }
            }
        }
        return items;
    }

    // Method to delete an order and its associated items
    public boolean deleteOrder(int orderID) throws SQLException {
        String deleteItemsQuery = "DELETE FROM orderitems WHERE OrderID = ?";
        String deleteOrderQuery = "DELETE FROM `order` WHERE OrderID = ?";

        try (PreparedStatement deleteItemsStmt = connection.prepareStatement(deleteItemsQuery);
             PreparedStatement deleteOrderStmt = connection.prepareStatement(deleteOrderQuery)) {

            // Delete associated items first
            deleteItemsStmt.setInt(1, orderID);
            deleteItemsStmt.executeUpdate();

            // Then delete the order itself
            deleteOrderStmt.setInt(1, orderID);
            int affectedRows = deleteOrderStmt.executeUpdate();
            return affectedRows > 0;  // Return true if the order was deleted
        }
    }
    
    // Method to fetch the highest OrderID from the database
    public int getNextOrderID() throws SQLException {
        String query = "SELECT MAX(OrderID) FROM `order`";  // Get the highest OrderID

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                // If there's at least one order, return the next ID
                int maxOrderID = rs.getInt(1);
                return maxOrderID + 1;  // Return the next OrderID
            }
        }

        // If no orders exist, return 1 (starting point for OrderIDs)
        return 1;
    }
    
    // Convert the boolean status to a readable string
    private String mapOrderStatusToString(int status) {
        return status == 0 ? "In Progress" : "Completed";
    }

    // Fetch all orders from the database, and map the status to a string
    public List<Order> fetchAllOrders() throws SQLException {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM `order`";  // Fetch all orders
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                // Map the status to a string ("In Progress" or "Completed")
                String status = mapOrderStatusToString(rs.getInt("OrderStatus"));
                orders.add(new Order(
                    rs.getInt("OrderID"),
                    rs.getString("CustomerName"),
                    rs.getString("PhoneNumber"),
                    rs.getDate("OrderDate"),
                    status  // Set the status as a String instead of boolean
                ));
            }
        }
        return orders;
    }

    // Method to calculate the total for an order (unchanged)
    public float calculateOrderTotal(int orderID) throws SQLException {
        String query = "SELECT oi.Quantity, i.Price FROM orderitems oi " +
                       "JOIN item i ON oi.ItemID = i.ItemID WHERE oi.OrderID = ?";
        float total = 0;
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderID);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    float itemPrice = rs.getFloat("Price");
                    int quantity = rs.getInt("Quantity");
                    total += itemPrice * quantity;
                }
            }
        }
        return total;
    }
}

