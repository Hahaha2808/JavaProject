package controller;

public class OrderItem {
    private int itemID;
    private int quantity;
    private double price;

    // Modified constructor to accept only itemID and quantity
    public OrderItem(int itemID, int quantity) {
        this.itemID = itemID;
        this.quantity = quantity;
        this.price = 0.0;  // Default value for price
    }

    // Getters and setters
    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
}
