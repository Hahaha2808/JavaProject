package controller;

import HRM.Item;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    private Connection connection;

    // Constructor
    public ItemDAO(Connection connection) {
        this.connection = connection;
    }

    // Method to add an item to the database
    public boolean addItem(Item item) {
        String query = "INSERT INTO item (name, description, price, availability) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, item.getName());
            stmt.setString(2, item.getDescription());
            stmt.setFloat(3, item.getPrice());
            stmt.setBoolean(4, item.isAvailable());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to update an item in the database
    public boolean updateItem(Item item) {
        String query = "UPDATE item SET name = ?, description = ?, price = ?, availability = ? WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, item.getName());
            stmt.setString(2, item.getDescription());
            stmt.setFloat(3, item.getPrice());
            stmt.setBoolean(4, item.isAvailable());
            stmt.setInt(5, item.getItemID());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete an item from the database
    public boolean deleteItem(int itemID) {
        String query = "DELETE FROM item WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to get an item by ID
    public Item getItemById(int itemID) {
        String query = "SELECT * FROM item WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Item(
                        rs.getInt("itemID"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getFloat("price"),
                        rs.getBoolean("availability")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to get all items in the database
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        String query = "SELECT * FROM item";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                items.add(new Item(
                        rs.getInt("itemID"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getFloat("price"),
                        rs.getBoolean("availability")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
    
    // Method to get items by name
    public List<Item> getItemsByName(String name) {
        List<Item> items = new ArrayList<>();
        String query = "SELECT * FROM item WHERE name LIKE ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, "%" + name + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                items.add(new Item(
                        rs.getInt("itemID"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getFloat("price"),
                        rs.getBoolean("availability")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }
    
    // Method to get the name of an item by ID
    public String getItemNameById(int itemID) {
        String query = "SELECT name FROM item WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }   

    // Method to get the price of an item by ID
    public float getItemPriceById(int itemID) {
        String query = "SELECT price FROM item WHERE itemID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getFloat("price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return an invalid value if the item is not found
    }
    
    // Method to get the item ID by name
    public int getItemIdByName(String name) {
        String query = "SELECT itemID FROM item WHERE name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("itemID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return an invalid ID if the item is not found
    }
    
    // Method to get items for a specific order
    public List<OrderItem> getOrderItemsByOrderId(int orderId) {
        List<OrderItem> orderItems = new ArrayList<>();
        String query = "SELECT oi.itemID, oi.quantity FROM orderitems oi WHERE oi.orderID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int itemID = rs.getInt("itemID");
                int quantity = rs.getInt("quantity");

                // Add the order item with itemID and quantity
                orderItems.add(new OrderItem(itemID, quantity));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItems;
    }

}
