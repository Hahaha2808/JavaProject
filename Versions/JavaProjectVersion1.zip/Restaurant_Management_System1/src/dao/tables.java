/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import javax.swing.JOptionPane;

public class Tables {
    public static void main(String[] args) {
        try {
            // Insert Admin Details
            //String adminDetails = "INSERT INTO User(username, password, name, role) VALUES ('waiterUser', 'waiterPass', 'Waiter Name', 'Waiter')";
            //DbOperations.setDataOrDelete(adminDetails, "Admin Details Added Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
